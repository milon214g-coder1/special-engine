package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FirebaseManager
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun UploadTab(firebaseManager: FirebaseManager, onUploadComplete: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var videoUrl by remember { mutableStateOf("") }
    var thumbnailUrl by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var success by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Upload Video", color = DarkOnSurface, fontWeight = FontWeight.Bold, fontSize = 24.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Share your vibe with the world", color = TextMuted, fontSize = 14.sp)
        
        Spacer(modifier = Modifier.height(48.dp))
        
        OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Video Title", color = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandRedLight,
                unfocusedBorderColor = BorderColor,
                focusedTextColor = DarkOnSurface,
                unfocusedTextColor = DarkOnSurface
            ),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = videoUrl,
            onValueChange = { videoUrl = it },
            label = { Text("Video File URL (optional)", color = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandRedLight,
                unfocusedBorderColor = BorderColor,
                focusedTextColor = DarkOnSurface,
                unfocusedTextColor = DarkOnSurface
            ),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = thumbnailUrl,
            onValueChange = { thumbnailUrl = it },
            label = { Text("Thumbnail URL (optional)", color = TextMuted) },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = BrandRedLight,
                unfocusedBorderColor = BorderColor,
                focusedTextColor = DarkOnSurface,
                unfocusedTextColor = DarkOnSurface
            ),
            singleLine = true
        )
        
        Spacer(modifier = Modifier.height(24.dp))
        
        if (success) {
            Text("Upload successful!", color = SuccessGreen, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(16.dp))
        }
        
        Button(
            onClick = {
                if (title.isBlank()) return@Button
                isLoading = true
                scope.launch {
                    firebaseManager.uploadVideo(
                        title = title,
                        videoUrl = videoUrl,
                        thumbnailUrl = thumbnailUrl
                    )
                    isLoading = false
                    success = true
                    title = ""
                    videoUrl = ""
                    thumbnailUrl = ""
                    onUploadComplete()
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = BrandRed),
            enabled = !isLoading && title.isNotBlank()
        ) {
            if (isLoading) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
            } else {
                Text("Upload", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}
