package com.example.ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.FirebaseManager

@Composable
fun AppNavigation(firebaseManager: FirebaseManager) {
    val navController = rememberNavController()
    val startDest = if (firebaseManager.isUserLoggedIn()) "main_app" else "login"

    NavHost(
        navController = navController,
        startDestination = startDest,
        modifier = Modifier.fillMaxSize()
    ) {
        composable("login") {
            LoginScreen(
                firebaseManager = firebaseManager,
                onLoginSuccess = {
                    navController.navigate("main_app") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        composable("main_app") {
            MainAppScreen(
                firebaseManager = firebaseManager,
                onNavigateToStudio = { navController.navigate("studio") },
                onLogout = {
                    navController.navigate("login") {
                        popUpTo("main_app") { inclusive = true }
                    }
                }
            )
        }
        composable("studio") {
            StudioDashboard(
                firebaseManager = firebaseManager,
                onBack = { navController.popBackStack() },
                onNavigateToVideo = { videoId ->
                    navController.navigate("video_detail/$videoId")
                }
            )
        }
        composable("video_detail/{videoId}") { backStackEntry ->
            val videoId = backStackEntry.arguments?.getString("videoId") ?: return@composable
            VideoDetailScreen(
                videoId = videoId,
                firebaseManager = firebaseManager,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
