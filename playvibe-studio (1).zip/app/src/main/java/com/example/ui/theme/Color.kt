package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Red80 = Color(0xFFFFB4AB)
val RedGrey80 = Color(0xFFE7BDB8)
val DarkRed80 = Color(0xFFFFB4A9)

val Red40 = Color(0xFFC00011)
val RedGrey40 = Color(0xFF775652)
val DarkRed40 = Color(0xFF93000A)

val DarkBackground = Color(0xFF0F0A0A)
val DarkSurface = Color(0xFF1A1414)
val DarkOnSurface = Color(0xFFF1F1F1)

val BrandRed = Color(0xFFE53935)
val BrandRedLight = Color(0xFFE57373)
val BrandRedDark = Color(0xFF8E0E0E)
val BrandRedGradientStart = Color(0xFF8E0E0E)
val TextMuted = Color(0xFFA18888)
val BorderColor = Color(0xFF2D1F1F)
val SuccessGreen = Color(0xFF34D399)
val WarningAmber = Color(0xFFFBBF24)
